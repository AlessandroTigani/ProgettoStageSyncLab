package it.synclab.prototipo.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.security.web.csrf.CsrfToken;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import it.synclab.prototipo.dto.UserDto;
import jakarta.servlet.http.HttpServletRequest;

@RestController
public class TextController {

    private List<UserDto> users = new ArrayList<>(List.of(
        new UserDto(1,"user1", "password", "email1@email.com" ),
        new UserDto(2,"user2", "password", "email2@email.com" )
    ));


    @GetMapping("/hello")
    public String test(HttpServletRequest request){
        return "Hello user" + request.getSession().getId();
    }

    @GetMapping("/user")
    public List<UserDto> getUsers(){
        return users;
    }

    @GetMapping("/csrf-token")
    public CsrfToken getCsrfToken(HttpServletRequest request){
        return (CsrfToken) request.getAttribute("_csrf");
    }

    @PostMapping("/insert-user")
    public UserDto addUser(@RequestBody UserDto userDto){
        users.add(userDto);
        return userDto;
    }
}
